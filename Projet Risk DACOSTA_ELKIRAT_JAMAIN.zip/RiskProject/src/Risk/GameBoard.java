package Risk;

import edu.princeton.cs.introcs.StdDraw;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class GameBoard extends JDialog {
    private JPanel chatboxPanel;
    //private JPanel mapPanel;
    private JPanel buttonPanel;

    private GridLayout mainLayout;
    private GridLayout chatboxLayout;
    //private GridLayout mapPanelLayout;
    private GridLayout buttonPanelLayout;

    private JButton attackBtn;
    private JButton passturnBtn;
    private JButton moveBtn;

    private JTextArea printTextArea;
    //private JScrollPane mapScrollPane;
    //private ImageIcon mapImageIcon;
    //public MapCountry[] mapCountries = new MapCountry[43];


    public GameBoard() {
        super();
        setTitle("Risk Game");


        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setResizable(false);

        mainLayout = new GridLayout(1, 3, 5, 5); //  Make second parameter '2' if including playerTypesPanel
        setLayout(mainLayout);

        add(chatboxPanel());
        //add(mapPanel());
        add(buttonPanel());

        setLocationRelativeTo(null);

        pack();

    }

    private JPanel chatboxPanel(){
        chatboxPanel = new JPanel();
        chatboxPanel.setPreferredSize(new Dimension(200, 650));
        chatboxLayout = new GridLayout(1, 1, 5, 5);
        chatboxPanel.setLayout(chatboxLayout);

        printTextArea=new JTextArea();
        printTextArea.setFocusable(false);
        printTextArea.setLineWrap(true);
        printTextArea.setWrapStyleWord(true);

        chatboxPanel.add(printTextArea);

        return chatboxPanel;


    }



    /**
     private JPanel mapPanel(){


     mapPanel = new JPanel();
     mapPanel.setPreferredSize(new Dimension(900, 600));
     //mapPanelLayout = new GridLayout(1, 1, 5, 5);
     mapPanel.setLayout(null);
     mapPanel.setCursor(java.awt.Cursor.getPredefinedCursor(1));
     //mapPanel.setLayout(mapPanelLayout);
     //mapImageIcon = new ImageIcon("carte.png");
     //mapScrollPane = new JScrollPane(new JLabel(mapImageIcon));
     //mapScrollPane.setPreferredSize(new Dimension(780, 680));
     //mapPanel.add(mapScrollPane);
     mapCountries[1] = new MapCountry("images/countries/001.gif", 1, 20, 12);
     mapCountries[1].setLocation(15, 35);
     mapCountries[1].setSize(53, 45);

     mapCountries[2] = new MapCountry("images/countries/002.gif", 2, 23, 12);
     mapCountries[2].setLocation(67, 38);
     mapCountries[2].setSize(67, 30);

     mapCountries[3] = new MapCountry("images/countries/003.gif", 3, 10, 23);
     mapCountries[3].setLocation(133, 25);
     mapCountries[3].setSize(57, 43);

     mapCountries[4] = new MapCountry("images/countries/004.gif", 4, 63, 20);
     mapCountries[4].setLocation(215, 15);
     mapCountries[4].setSize(144, 70);

     mapCountries[5] = new MapCountry("images/countries/005.gif", 5, 27, 20);
     mapCountries[5].setLocation(67, 67);
     mapCountries[5].setSize(57, 46);

     mapCountries[6] = new MapCountry("images/countries/006.gif", 6, 25, 20);
     mapCountries[6].setLocation(123, 67);
     mapCountries[6].setSize(69, 46);

     mapCountries[7] = new MapCountry("images/countries/007.gif", 7, 15, 20);
     mapCountries[7].setLocation(191, 59);
     mapCountries[7].setSize(71, 54);

     mapCountries[8] = new MapCountry("images/countries/008.gif", 8, 23, 15);
     mapCountries[8].setLocation(82, 112);
     mapCountries[8].setSize(55, 54);

     mapCountries[9] = new MapCountry("images/countries/009.gif", 9, 23, 15);
     mapCountries[9].setLocation(136, 112);
     mapCountries[9].setSize(81, 50);

     mapCountries[10] = new MapCountry("images/countries/010.gif", 10, 17, 10);
     mapCountries[10].setLocation(115, 152);
     mapCountries[10].setSize(74, 53);

     mapCountries[11] = new MapCountry("images/countries/011.gif", 11, 40, 10);
     mapCountries[11].setLocation(177, 199);
     mapCountries[11].setSize(95, 29);

     mapCountries[12] = new MapCountry("images/countries/012.gif", 12, 30, 28);
     mapCountries[12].setLocation(186, 227);
     mapCountries[12].setSize(56, 74);

     mapCountries[13] = new MapCountry("images/countries/013.gif", 13, 25, 28);
     mapCountries[13].setLocation(241, 227);
     mapCountries[13].setSize(74, 74);

     mapCountries[14] = new MapCountry("images/countries/014.gif", 14, 23, 20);
     mapCountries[14].setLocation(203, 300);
     mapCountries[14].setSize(81, 83);

     mapCountries[15] = new MapCountry("images/countries/015.gif", 15, 40, 30);
     mapCountries[15].setLocation(318, 52);
     mapCountries[15].setSize(64, 49);

     mapCountries[16] = new MapCountry("images/countries/016.gif", 16, 9, 32);
     mapCountries[16].setLocation(346, 87);
     mapCountries[16].setSize(48, 48);

     mapCountries[17] = new MapCountry("images/countries/017.gif", 17, 19, 20);
     mapCountries[17].setLocation(387, 38);
     mapCountries[17].setSize(99, 42);

     mapCountries[18] = new MapCountry("images/countries/018.gif", 18, 42, 11);
     mapCountries[18].setLocation(393, 71);
     mapCountries[18].setSize(59, 26);

     mapCountries[19] = new MapCountry("images/countries/019.gif", 19, 32, 6);
     mapCountries[19].setLocation(393, 96);
     mapCountries[19].setSize(60, 39);

     mapCountries[20] = new MapCountry("images/countries/020.gif", 20, 42, 32);
     mapCountries[20].setLocation(432, 45);
     mapCountries[20].setSize(82, 76);

     mapCountries[21] = new MapCountry("images/countries/021.gif", 21, 40, 17);
     mapCountries[21].setLocation(445, 119);
     mapCountries[21].setSize(110, 80);

     mapCountries[22] = new MapCountry("images/countries/022.gif", 22, 40, 28);
     mapCountries[22].setLocation(514, 30);
     mapCountries[22].setSize(97, 93);

     mapCountries[23] = new MapCountry("images/countries/023.gif", 23, 30, 20);
     mapCountries[23].setLocation(513, 81);
     mapCountries[23].setSize(73, 66);

     mapCountries[24] = new MapCountry("images/countries/024.gif", 24, 28, 18);
     mapCountries[24].setLocation(554, 146);
     mapCountries[24].setSize(63, 66);

     mapCountries[25] = new MapCountry("images/countries/025.gif", 25, 15, 42);
     mapCountries[25].setLocation(611, 19);
     mapCountries[25].setSize(75, 104);

     mapCountries[26] = new MapCountry("images/countries/026.gif", 26, 25, 12);
     mapCountries[26].setLocation(666, 30);
     mapCountries[26].setSize(63, 32);

     mapCountries[27] = new MapCountry("images/countries/027.gif", 27, 30, 10);
     mapCountries[27].setLocation(650, 61);
     mapCountries[27].setSize(79, 28);

     mapCountries[28] = new MapCountry("images/countries/028.gif", 28, 33, 13);
     mapCountries[28].setLocation(637, 88);
     mapCountries[28].setSize(92, 52);

     mapCountries[29] = new MapCountry("images/countries/029.gif", 29, 57, 17);
     mapCountries[29].setLocation(586, 122);
     mapCountries[29].setSize(123, 40);

     mapCountries[30] = new MapCountry("images/countries/030.gif", 30, 30, 13);
     mapCountries[30].setLocation(616, 161);
     mapCountries[30].setSize(87, 70);

     mapCountries[31] = new MapCountry("images/countries/031.gif", 31, 27, 12);
     mapCountries[31].setLocation(729, 33);
     mapCountries[31].setSize(86, 81);

     mapCountries[32] = new MapCountry("images/countries/032.gif", 32, 8, 32);
     mapCountries[32].setLocation(720, 112);
     mapCountries[32].setSize(40, 51);

     mapCountries[33] = new MapCountry("images/countries/033.gif", 33, 44, 14);
     mapCountries[33].setLocation(630, 215);
     mapCountries[33].setSize(88, 53);

     mapCountries[34] = new MapCountry("images/countries/034.gif", 34, 52, 65);
     mapCountries[34].setLocation(690, 180);
     mapCountries[34].setSize(93, 85);

     mapCountries[35] = new MapCountry("images/countries/035.gif", 35, 30, 30);
     mapCountries[35].setLocation(680, 275);
     mapCountries[35].setSize(65, 64);

     mapCountries[36] = new MapCountry("images/countries/036.gif", 36, 15, 40);
     mapCountries[36].setLocation(744, 272);
     mapCountries[36].setSize(47, 78);

     mapCountries[37] = new MapCountry("images/countries/037.gif", 37, 35, 40);
     mapCountries[37].setLocation(327, 134);
     mapCountries[37].setSize(116, 90);

     mapCountries[38] = new MapCountry("images/countries/038.gif", 38, 30, 28);
     mapCountries[38].setLocation(395, 133);
     mapCountries[38].setSize(85, 53);

     mapCountries[39] = new MapCountry("images/countries/039.gif", 39, 18, 27);
     mapCountries[39].setLocation(442, 185);
     mapCountries[39].setSize(71, 72);

     mapCountries[40] = new MapCountry("images/countries/040.gif", 40, 18, 15);
     mapCountries[40].setLocation(399, 220);
     mapCountries[40].setSize(44, 37);

     mapCountries[41] = new MapCountry("images/countries/041.gif", 41, 30, 25);
     mapCountries[41].setLocation(405, 256);
     mapCountries[41].setSize(79, 73);

     mapCountries[42] = new MapCountry("images/countries/042.gif", 42, 11, 23);
     mapCountries[42].setLocation(490, 256);
     mapCountries[42].setSize(35, 55);

     //mapCountryListener = new GameWindow.MapMouseListener(null);

     for (int i = 1; i < 43; i++) {
     mapPanel.add(mapCountries[i]);
     //mapCountries[i].addMouseListener(mapCountryListener);
     }
     return mapPanel;



     }

     **/

    private JPanel buttonPanel(){
        buttonPanel = new JPanel();
        buttonPanel.setPreferredSize(new Dimension(200, 650));
        buttonPanelLayout = new GridLayout(3, 1, 5, 5);
        buttonPanel.setLayout(buttonPanelLayout);
        attackBtn = new JButton ("Attack");
        moveBtn = new JButton ("Move");
        passturnBtn = new JButton ("Pass");

        //startBtn.setActionCommand(startBtnName);
        GameBoard.GUIListener event = new GameBoard.GUIListener();
        attackBtn.addActionListener(event);
        moveBtn.addActionListener(event);
        passturnBtn.addActionListener(event);

        buttonPanel.add(attackBtn);
        buttonPanel.add(moveBtn);
        buttonPanel.add(passturnBtn);

        return buttonPanel;
    }

    public class GUIListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource()==attackBtn){
                //Menu.setVisible(false);

                // what to do when attack is pressed

            }
            else if (e.getSource()==moveBtn){
                //StdDraw.setCanvasSize(1227, 628);
                //StdDraw.setXscale(0, 1000);/* INITIALISATION DE LA TAILLE DE LA FENETRE */
                //StdDraw.setYscale(0, 1000);
                //StdDraw.setPenColor(StdDraw.BLACK);
                //StdDraw.clear(StdDraw.WHITE);
                //StdDraw.picture(500, 500, "images/carte.png");


                // what to do when move is pressed




            }
            else if(e.getSource()==passturnBtn) {
                // what to do when pass is pressed
            }
        }
    }
}
