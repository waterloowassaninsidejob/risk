package Risk;

public class Occupant {
    public int habitant;
    public Occupant(int hab) {
        this.habitant=hab;
    }
    public int getHabitant() {
        return habitant;
    }
    public void setHabitant(int habitant) {
        this.habitant = habitant;
    }
    public void nbrhab(int habitant) {

    }
}
