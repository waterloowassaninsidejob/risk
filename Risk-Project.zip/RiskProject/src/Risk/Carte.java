package Risk;

public class Carte {
    public int habitant;
    public Carte(int hab) {
        this.habitant=hab;
    }
    public int getHabitant() {
        return habitant;
    }
    public void setHabitant(int habitant) {
        this.habitant = habitant;
    }
    public void nbrhab(int habitant) {

    }
}
