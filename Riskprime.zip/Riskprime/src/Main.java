import edu.princeton.cs.introcs.StdDraw;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StdDraw.setCanvasSize(1227, 628);
		StdDraw.setXscale(0, 1000);/* INITIALISATION DE LA TAILLE DE LA FENETRE */
		StdDraw.setYscale(0, 1000);
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.text(500, 500, "RISK");
		StdDraw.text(500, 100, "Jouer");
		int choix = 0;
		int choix2 = 1;
		while (choix != 1) {
			if (StdDraw.isMousePressed()) {
				double x = StdDraw.mouseX();
				double y = StdDraw.mouseY();
				if (0 < y && 1000 > y && 0 < x && 1000 > x) {
					StdDraw.pause(100);
					StdDraw.clear(StdDraw.WHITE);
					StdDraw.setPenColor(StdDraw.BLACK);
					StdDraw.text(500, 800, "MENU");
					StdDraw.text(300, 700, "S�lectionnez le nombre de joueurs : ");
					StdDraw.text(500, 500, "2 joueurs");
					StdDraw.text(500, 400, "3 joueurs");
					StdDraw.text(500, 300, "4 joueurs");
					StdDraw.text(500, 200, "5 joueurs");
					StdDraw.text(500, 100, "6 joueurs");
					choix = 1;
					choix2 = 0;
				}
			}
		}
		while (choix2 != 1) {
			if (StdDraw.isMousePressed()) {
				double i = StdDraw.mouseX();
				double j = StdDraw.mouseY();

				if (450 < j && 550 > j && 450 < i && 550 > i) {
					StdDraw.clear(StdDraw.WHITE);
					choix2 = 2;
					break;
				} else if (350 < j && 450 > j && 450 < i && 550 > i) {
					StdDraw.clear(StdDraw.WHITE);
					choix2 = 3;
					break;
				} else if (250 < j && 350 > j && 450 < i && 550 > i) {
					StdDraw.clear(StdDraw.WHITE);
					choix2 = 4;
					break;
				} else if (150 < j && 250 > j && 450 < i && 550 > i) {
					StdDraw.clear(StdDraw.WHITE);
					choix2 = 5;
					break;
				} else if (50 < j && 150 > j && 450 < i && 550 > i) {
					StdDraw.clear(StdDraw.WHITE);
					choix2 = 6;
					break;
				}
			}
		}

		switch (choix2) {

		case 2:

			int choix3 = 1;
			
			  StdDraw.picture(500, 500, "image/carte.png");
			  StdDraw.setPenColor(178,190,181); 
			  StdDraw.filledCircle(68, 885, 20);//Alaska
			  StdDraw.filledCircle(140, 885, 20);//Canada 
			  StdDraw.filledCircle(125, 815, 20);//Montana 
			  StdDraw.filledCircle(190, 810, 20);//Ontario
			  StdDraw.filledCircle(255, 805, 15);//Qu�bec 
			  StdDraw.filledCircle(240, 185, 15);//Argentine 
			  StdDraw.filledCircle(237, 307, 15);//P�rou
			  StdDraw.filledCircle(284, 340, 20);//Br�sil 
			  StdDraw.filledCircle(223, 466, 20);//V�n�zuela 
			  StdDraw.filledCircle(530, 274, 20);//Afrique du Sud
			  StdDraw.filledCircle(610, 281, 15);//Madagascar 
			  StdDraw.filledCircle(530, 414, 20);//Congo 
			  StdDraw.filledCircle(582, 480, 20);//Ethiopie
			  StdDraw.filledCircle(450, 548, 20);//Sahara 
			  StdDraw.filledCircle(530, 614, 20);//Egypte 
			  StdDraw.filledCircle(461, 739, 15);//France
			  StdDraw.filledCircle(850,222,20);//Perth
			  StdDraw.filledCircle(930,229,18);//Sydney
			  StdDraw.filledCircle(934,380,15);//Nouvelle Cal�donie
			  StdDraw.filledCircle(840,422,15);//Indon�sie
			  StdDraw.filledCircle(776,659,20);//Chine
			  StdDraw.filledCircle(719,585,20);//Inde
			  StdDraw.filledCircle(588,669,20);//Turquie
			  StdDraw.filledCircle(907,681,15);//Japon
			  StdDraw.filledCircle(784,740,20);//Mongolie
			  StdDraw.filledCircle(776,800,20);//Irkusta
			  StdDraw.filledCircle(885,874,20);//Kamchatka
			  StdDraw.filledCircle(792,884,20);//Yakust
			  StdDraw.filledCircle(712,877,20);//Sib�rie
			  StdDraw.filledCircle(654,844,20);//Ural
			  StdDraw.filledCircle(662,741,20);//Afghanistan
			  StdDraw.filledCircle(526,731,15);//Gr�ce
			  StdDraw.filledCircle(431,800,15);//Angleterre
			  StdDraw.filledCircle(412,862,15);//Islande
			  StdDraw.filledCircle(504,867,15);//Scandinavie
			  StdDraw.filledCircle(569,807,20);//Russie
			  StdDraw.filledCircle(500,793,15);//Allemagne
			  StdDraw.filledCircle(100,730,20);//West
			  StdDraw.filledCircle(180,700,20);//East
			  StdDraw.filledCircle(110,600,20);//Mexique
			  StdDraw.filledCircle(360,930,20);//Gro�nland
			  StdDraw.filledCircle(800,542,15);//Tha�lande
			 
			carte carte = new carte(19);
			int x = 1 ;
			int y = carte.getHabitant();
			System.out.println(y);
			
			
			while (y != 0) {
				if (StdDraw.isMousePressed()) {
					double k = StdDraw.mouseX();
					double l = StdDraw.mouseY();
					if (k < 810 && k > 790 && l < 552 && l > 532) {
						y = y - 1;
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(800,542,15);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(800, 542, Integer.toString(x));
						
						StdDraw.pause(500);
					}
					
					else if (k < 370 && k > 350 && l < 940 && l > 920) {
	                    y = y - 1;
	                    x++;
	                    StdDraw.setPenColor(178,190,181);
	                    StdDraw.filledCircle(360,930,20);
	                    StdDraw.setPenColor(StdDraw.BLACK);
	                    StdDraw.text(360, 930, Integer.toString(x));
	                    StdDraw.pause(500);

	                }
					else if (k < 78 && k > 58 && l < 895 && l > 875) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(68, 885,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(68, 885, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 150 && k > 130 && l < 895 && l > 875) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(140, 885,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(140, 885, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 135 && k > 115 && l < 825 && l > 805) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(125, 815,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(125, 815, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 200 && k > 180 && l < 820 && l > 800) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(190, 810,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(190, 810, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 265 && k > 245 && l < 815 && l > 795) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(255, 805,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(255, 805, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 250 && k > 220 && l < 195 && l > 175) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(240, 185,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(240, 185, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 247 && k > 227 && l < 317 && l > 297) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(237, 307,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(237, 307, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 294 && k > 274 && l < 350 && l > 330) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(284, 340,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(284, 340, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 233 && k > 213 && l < 476 && l > 456) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(223, 466,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(223, 466, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 540 && k > 520 && l < 284 && l > 264) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(530, 274,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(530, 274, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 620 && k > 600 && l < 291 && l > 271) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(610, 281,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(610, 281, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 540 && k > 520 && l < 424 && l > 404) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(530, 414,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(530, 414, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 592 && k > 572 && l < 490 && l > 470) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(582, 480,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(582, 480, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 460 && k > 440 && l < 558 && l > 538) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(450, 548,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(450, 548, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 540 && k > 520 && l < 624 && l > 604) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(530, 614,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(530, 614, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 471 && k > 451 && l < 749 && l > 729) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(461, 739,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(461, 739, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 860 && k > 840 && l < 232 && l > 212) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(850,222,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(850,222, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 940 && k > 920 && l < 239 && l > 219) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(930,229,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(930,229, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 944 && k > 924 && l < 390 && l > 370) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(934,380,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(934,380, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 850 && k > 830 && l < 432 && l > 412) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(840,422,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(840,422, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 786 && k > 766 && l < 669 && l > 649) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(776,659,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(776,659, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 729 && k > 709 && l < 595 && l > 575) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(719,585,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(719,585, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 598 && k > 578 && l < 679 && l > 659) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(588,669,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(588,669, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 917 && k > 897 && l < 691 && l > 671) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(907,681,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(907,681, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 794 && k > 774 && l < 750 && l > 730) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(784,740,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(784,740, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 786 && k > 766 && l < 810 && l > 790) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(776,800,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(776,800, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 895 && k > 875 && l < 884 && l > 864) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(885,874,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(885,874, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 802 && k > 782 && l < 894 && l > 874) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(792,884,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(792,884, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 722 && k > 702 && l < 887 && l > 867) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(712,877,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(712,877, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 664 && k > 644 && l < 854 && l > 834) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(654,844,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(654,844, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 672 && k > 652 && l < 751 && l > 731) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(662,741,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(662,741, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 536 && k > 516 && l < 741 && l > 721) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(526,731,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(526,731, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 441 && k > 421 && l < 810 && l > 490) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(431,800,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(431,800, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 422 && k > 402 && l < 872 && l > 852) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(412,862,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(412,862, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 514 && k > 494 && l < 877 && l > 857) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(504,867,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(504,867, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 579 && k > 559 && l < 817 && l > 797) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(569,807,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(569,807, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 510 && k > 490 && l < 803 && l > 783) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(500,793,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(500,793, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 110 && k > 90 && l < 740 && l > 720) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(100,730,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(100,730, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 190 && k > 170 && l < 710 && l > 690) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(180,700,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(180,700, Integer.toString(x));
						StdDraw.pause(500);
					}
					else if (k < 120 && k > 100 && l < 610 && l > 590) {
						y = y - 1;	
						x++;
						StdDraw.setPenColor(178,190,181); 
						StdDraw.filledCircle(110,600,20);
						StdDraw.setPenColor(StdDraw.BLACK);
						StdDraw.text(110,600, Integer.toString(x));
						StdDraw.pause(500);
					}
				}
			}
			break;
		case 3:
			StdDraw.picture(500, 500, "image/carte.png");
			break;
		case 4:
			StdDraw.picture(500, 500, "image/carte.png");
			break;
		case 5:
			StdDraw.picture(500, 500, "image/carte.png");
			break;
		case 6:
			StdDraw.picture(500, 500, "image/carte.png");
			break;
		}
}
}
