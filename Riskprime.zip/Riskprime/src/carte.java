
public class carte {
	public int habitant;
	public carte(int hab) {
		this.habitant=hab;
	}
	public int getHabitant() {
		return habitant;
	}
	public void setHabitant(int habitant) {
		this.habitant = habitant;
	}
	public void nbrhab(int habitant) {
		
}

}
